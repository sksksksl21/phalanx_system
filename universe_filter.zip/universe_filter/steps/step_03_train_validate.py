# =========================================================
# Step 03 - Train & Walk-forward Validate
# ---------------------------------------------------------
# Generated: 2026-02-03T13:29:24Z
#
# HARD RULES (v1.0):
# - Strategy logic (entry/positioning/exit) MUST NOT be modified.
# - UF MUST output ONLY universe.json for engine consumption.
# - All files MUST live under universe_filter/.
# - Pipeline is step-by-step; each step is a single runnable module.
# - Only Step 05 writes output/universe.json.
# =========================================================

"""
Role
----
Trains RandomForest with constraints and validates via walk-forward; computes stability objectives (MDD/std/IQR).

Inputs
------
- universe_filter/output/cache/uf_dataset.parquet
- universe_filter/config/uf_config.json

Outputs
-------
- (optional) universe_filter/output/cache/model.pkl
- universe_filter/output/decision_table.csv
- universe_filter/output/run_report.json

Notes
-----
- RandomForest constraints: max_depth <= 5, min_samples_leaf >= 10.
- Permutation importance pruning: drop bottom 20% features (1~3 loops).
- Objective vector: MDD down, trade_count_std down, holding_iqr down.
"""
