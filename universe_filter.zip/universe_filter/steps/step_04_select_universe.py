# =========================================================
# Step 04 - Select Universe
# ---------------------------------------------------------
# Generated: 2026-02-03T13:29:24Z
#
# HARD RULES (v1.0):
# - Strategy logic (entry/positioning/exit) MUST NOT be modified.
# - UF MUST output ONLY universe.json for engine consumption.
# - All files MUST live under universe_filter/.
# - Pipeline is step-by-step; each step is a single runnable module.
# - Only Step 05 writes output/universe.json.
# =========================================================

"""
Role
----
Selects N symbols for next rebalance using model scores + safety gates; writes selected_symbols.json (cache).

Inputs
------
- universe_filter/output/cache/uf_dataset.parquet (latest asof snapshot)
- (optional) universe_filter/output/cache/model.pkl
- universe_filter/config/uf_config.json

Outputs
-------
- universe_filter/output/cache/selected_symbols.json
- universe_filter/output/decision_table.csv (final asof update)
- (report additions) universe_filter/output/run_report.json

Notes
-----
- Default: pick top-N by model score.
- Safety: exclude trade_count_7d=0; exclude insufficient history (<90d) by default.
- Optional config: force-include majors (still does not touch strategy).
"""
