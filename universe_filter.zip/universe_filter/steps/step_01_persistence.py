# =========================================================
# Step 01 - Persistence Check (EDA Gate)
# ---------------------------------------------------------
# Generated: 2026-02-03T13:29:24Z
#
# HARD RULES (v1.0):
# - Strategy logic (entry/positioning/exit) MUST NOT be modified.
# - UF MUST output ONLY universe.json for engine consumption.
# - All files MUST live under universe_filter/.
# - Pipeline is step-by-step; each step is a single runnable module.
# - Only Step 05 writes output/universe.json.
# =========================================================

"""
Role
----
Quickly checks whether past performance relates to next-period performance; influences feature policy only.

Inputs
------
- universe_filter/output/cache/trades.parquet

Outputs
-------
- universe_filter/output/run_report.json
- (optional) universe_filter/output/persistence_table.csv

Notes
-----
- Pipeline must NOT stop here; it only writes guidance flags.
- Compute Pearson/Spearman correlations on walk-forward style slices.
"""
