# Universe Filter (UF) - v1.0 Scaffold

_Generated: 2026-02-03T13:29:24Z_

- UF runs BEFORE strategy; it selects the tradable symbol list only.
- Strategy logic (entry/positioning/exit) must NOT be modified.
- Pipeline is step-by-step: steps/step_00 ~ step_05.
- Only steps/step_05_export_universe.py writes output/universe.json.
- Primary input: input/backtest_history.csv
- Optional input: input/ohlcv/* (if absent, OHLCV features are skipped safely).
- Entry point: run_pipeline.py (will orchestrate steps).
