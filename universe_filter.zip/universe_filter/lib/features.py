# =========================================================
# Universe Filter - lib/features.py
# ---------------------------------------------------------
# Generated: 2026-02-03T13:29:24Z
#
# HARD RULES (v1.0):
# - Strategy logic (entry/positioning/exit) MUST NOT be modified.
# - UF MUST output ONLY universe.json for engine consumption.
# - All files MUST live under universe_filter/.
# - Pipeline is step-by-step; each step is a single runnable module.
# - Only Step 05 writes output/universe.json.
# =========================================================

"""
Role
----
Feature builder enforcing caps (<=20, outcome-based <=3), OHLCV-optional feature gating, corr-cut.

Inputs
------
- (varies)

Outputs
-------
- (varies)

Notes
-----
- This is a shared library module (NOT a runnable step).
- Must not touch strategy logic; only UF data/modeling/selection/reporting.
"""
